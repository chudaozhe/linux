<?php

  // core config parameters
  $sDefaultLanguage      = "zh-cn";
  $sConfigDefaultView    = "thismonth.all";
  $bConfigChangeSites    = false;
  $bConfigUpdateSites    = false;
  $sUpdateSiteFilename   = "xml_update.php";

  // individual site configuration
  $aConfig["cuiwei.net"] = array(
    "statspath"   => "/var/lib/awstats/",
    // "statspath"   => "/data/apps/awstats/data/",
  	"statsname"   => "awstats[MM][YYYY].cuiwei.net.txt",
    "updatepath"  => "/usr/local/awstats/wwwroot/cgi-bin/awstats.pl/",
    // "updatepath" => "/usr/local/awstats/wwwroot/cgi-bin/awstats.pl/",
    "siteurl"     => "http://jawstats.cuiwei.net",
    "sitename"    => "This is my main website!",
    "theme"       => "default",
    "fadespeed"   => 250,
    "password"    => "my-1st-password",
    "includes"    => "",
    "language"    => "zh-cn"
  );

  $aConfig["site2"] = array(
    "statspath"   => "/path/to/data/",
    "updatepath"  => "/path/to/awstats.pl/",
    "siteurl"     => "http://www.my-2nd-domain.com",
    "sitename"    => "",
    "theme"       => "default",
    "fadespeed"   => 250,
    "password"    => "my-2nd-password",
    "includes"    => "",
    "language"    => "en-gb"
  );

?>
